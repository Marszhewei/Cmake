// get project version
#define VERSION_MAJOR 1
#define VERSION_MINOR 2
#define BUILD_SHARED_LIBS
